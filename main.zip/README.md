# MSU Thesis LaTeX Template
## มหาวิทยาลัยมหาสารคาม — เทมเพลตวิทยานิพนธ์ LaTeX

---

## โครงสร้างโฟลเดอร์ (Folder Structure)

```
thesis/
│
├── main_th.tex          ← ไฟล์หลัก เวอร์ชันภาษาไทย
├── main_en.tex          ← ไฟล์หลัก เวอร์ชันภาษาอังกฤษ
├── references.bib       ← ฐานข้อมูลบรรณานุกรม
│
├── Style/
│   ├── msu_thesis.cls   ← คลาสหลักของวิทยานิพนธ์
│   └── msu_thesis.sty   ← Style เพิ่มเติม
│
├── Cover/
│   ├── cover_outer_th.tex   ← ปกนอกภาษาไทย
│   ├── cover_outer_en.tex   ← ปกนอกภาษาอังกฤษ
│   ├── cover_inner_th.tex   ← ปกในภาษาไทย
│   ├── cover_inner_en.tex   ← ปกในภาษาอังกฤษ
│   ├── approval.tex         ← หน้าอนุมัติ
│   ├── abstract_th.tex      ← บทคัดย่อภาษาไทย
│   ├── abstract_en.tex      ← บทคัดย่อภาษาอังกฤษ
│   ├── acknowledgment.tex   ← กิตติกรรมประกาศ
│   └── biography.tex        ← ประวัติผู้เขียน
│
├── Chapter/
│   ├── chapter1.tex     ← บทที่ 1 บทนำ
│   ├── chapter2.tex     ← บทที่ 2 เอกสารและงานวิจัยที่เกี่ยวข้อง
│   ├── chapter3.tex     ← บทที่ 3 วิธีการดำเนินการ
│   ├── chapter4.tex     ← บทที่ 4 ผลการทดลองและอภิปรายผล
│   └── chapter5.tex     ← บทที่ 5 สรุปผลและข้อเสนอแนะ
│
├── Appendix/
│   └── appendix.tex     ← ภาคผนวก
│
├── Figure/
│   └── (วางไฟล์ภาพ .png / .pdf / .jpg ที่นี่)
│
└── Fonts/
    ├── THSarabunNew-Regular.ttf
    ├── THSarabunNew-Bold.ttf
    ├── THSarabunNew-Italic.ttf
    └── THSarabunNew-BoldItalic.ttf
```

---

## การติดตั้งฟอนต์ (Font Installation)

1. ดาวน์โหลดฟอนต์ **TH Sarabun New** จาก:
   - https://www.f0nt.com/release/th-sarabun-new/
   - หรือ https://github.com/SarabunThaiFont/THSarabunNew

2. วางไฟล์ฟอนต์ทั้ง 4 ไฟล์ในโฟลเดอร์ `Fonts/`:
   ```
   Fonts/
   ├── THSarabunNew-Regular.ttf
   ├── THSarabunNew-Bold.ttf
   ├── THSarabunNew-Italic.ttf
   └── THSarabunNew-BoldItalic.ttf
   ```

---

## การ Compile (Compilation)

> **⚠️ ต้องใช้ XeLaTeX เท่านั้น** (ไม่รองรับ pdfLaTeX)

### เวอร์ชันภาษาไทย
```bash
xelatex main_th
bibtex main_th
xelatex main_th
xelatex main_th
```

### เวอร์ชันภาษาอังกฤษ
```bash
xelatex main_en
bibtex main_en
xelatex main_en
xelatex main_en
```

### ใช้ Latexmk (แนะนำ)
```bash
latexmk -xelatex main_th.tex
latexmk -xelatex main_en.tex
```

---

## การแก้ไขข้อมูลวิทยานิพนธ์

เปิดไฟล์ `main_th.tex` หรือ `main_en.tex` แล้วแก้ไขส่วน **Thesis Information**:

```latex
\thesistitle{ชื่อวิทยานิพนธ์ภาษาไทย}
\thesistitleEN{English Title of the Thesis}
\authorname{ชื่อ นามสกุล}
\authornameEN{Firstname Lastname}
\advisorname{ศาสตราจารย์ ดร.\ ชื่อ นามสกุล}
\advisornameEN{Professor Firstname Lastname, Ph.D.}
\degreename{วิศวกรรมศาสตรมหาบัณฑิต}
\degreenameEN{Master of Engineering}
\majorname{วิศวกรรมไฟฟ้าและคอมพิวเตอร์}
\majornameEN{Electrical and Computer Engineering}
\thesisyear{กรกฎาคม 2568}
\thesisyearEN{July 2025}
\studentid{67010000000}
```

---

## การแทรกภาพ (Inserting Figures)

วางไฟล์ภาพใน `Figure/` แล้วใช้คำสั่ง:

```latex
\begin{figure}[htbp]
  \centering
  \includegraphics[width=0.7\textwidth]{../Figure/ชื่อไฟล์.png}
  \caption{คำอธิบายภาพ}
  \label{fig:label}
\end{figure}
```

---

## การแทรกตาราง (Inserting Tables)

```latex
\begin{table}[htbp]
  \centering
  \caption{ชื่อตาราง}
  \label{tab:label}
  \begin{tabular}{lll}
    \toprule
    หัวคอลัมน์ 1 & หัวคอลัมน์ 2 & หัวคอลัมน์ 3 \\
    \midrule
    ข้อมูล 1 & ข้อมูล 2 & ข้อมูล 3 \\
    \bottomrule
  \end{tabular}
\end{table}
```

---

## การอ้างอิง (Citations)

เพิ่มข้อมูลอ้างอิงใน `references.bib` แล้วอ้างอิงในเนื้อหาด้วย:

```latex
\cite{ref1}          % [1]
\cite{ref1,ref2}     % [1], [2]
```

---

## Editors ที่แนะนำ

| Editor | Platform | ลิงก์ |
|--------|----------|-------|
| TeXstudio | Windows/Mac/Linux | https://www.texstudio.org/ |
| Overleaf | เว็บไซต์ (ออนไลน์) | https://www.overleaf.com/ |
| VS Code + LaTeX Workshop | Windows/Mac/Linux | https://marketplace.visualstudio.com/items?itemName=James-Yu.latex-workshop |

> **Overleaf:** เมื่อใช้กับ Overleaf ให้ตั้งค่า Compiler เป็น **XeLaTeX** ใน Menu > Settings > Compiler

---

## ปัญหาที่พบบ่อย

**ภาษาไทยไม่แสดง / ฟอนต์ผิด**
→ ตรวจสอบว่าวางไฟล์ฟอนต์ในโฟลเดอร์ `Fonts/` ครบถ้วน และใช้ XeLaTeX ในการ compile

**สารบัญไม่อัปเดต**
→ Compile ซ้ำ 2–3 ครั้ง หรือใช้ `latexmk`

**เลขหน้าภาษาไทย (ก ข ค...) ไม่แสดง**
→ ตรวจสอบว่า `\pagestyle{frontmatter}` ถูกตั้งค่าในส่วน front matter

---

*Template สร้างสำหรับมหาวิทยาลัยมหาสารคาม คณะวิศวกรรมศาสตร์*
